This is a placeholder package.

Replace /private/scoutfile-skill-package.zip with your real product zip:
 - the skill file (.md)
 - your three brief templates
 - the install guide
 - the customization playbook

Keep the same filename, or update fileName in config/site.js.
